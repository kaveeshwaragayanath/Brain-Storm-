import sys
import numpy as np
import matplotlib.pyplot as plt
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QGridLayout, QDesktopWidget, QLineEdit
from PyQt5 import QtCore
from PyQt5.QtGui import QPixmap, QIcon, QFont
import pyaudio
import csv
import pandas as pd
import wave
import tkinter as tk
from tkinter import filedialog

# Rest of your code...


class AnotherWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Another Window')

        layout = QVBoxLayout()

        self.input_label1 = QLabel('Enter ECG CSV name :', self)
        self.input_label1.setStyleSheet('font-size: 16px;')
        self.input_text1 = QLineEdit(self)

        self.input_label2 = QLabel('Enter PCG CSV name :', self)
        self.input_label2.setStyleSheet('font-size: 16px;')
        self.input_text2 = QLineEdit(self)

        self.ok_button = QPushButton('OK', self)
        self.ok_button.clicked.connect(self.runPythonCode)

        layout.addWidget(self.input_label1)
        layout.addWidget(self.input_text1)
        layout.addWidget(self.input_label2)
        layout.addWidget(self.input_text2)
        layout.addWidget(self.ok_button)

        self.setLayout(layout)

    def runPythonCode(self):
        input_value1 = self.input_text1.text()
        input_value2 = self.input_text2.text()

        # Execute the Python code from hi.py file
        with open('Record.py', 'r') as file:
            code = file.read()

        # Create a dictionary to use as the global and local variables scope for executing the code
        exec_globals = {}
        exec_locals = {'input_value1': input_value1, 'input_value2': input_value2}

        try:
            exec(code, exec_globals, exec_locals)
        except Exception as e:
            print('Error occurred while executing the Python code:', str(e))

        # Close the AnotherWindow after executing the code
        self.close()


class MyWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.initUI()

    def initUI(self):
        self.setWindowTitle('Intelliscope')

        # Set background image
        #background_label = QLabel(self)
        #pixmap = QPixmap('background_image.jpg')
        #background_label.setPixmap(pixmap)
        #background_label.setGeometry(0, 0, self.width(), self.height())

        font_size = 20  # Define the desired font size

        self.label = QLabel('PCG & ECG Plotter', self)
        self.label.setStyleSheet(f"color: black; font-size: {60}px;")
        self.label.setAlignment(QtCore.Qt.AlignCenter)

        self.button1 = QPushButton('Plot Graphs', self)
        self.button1.setStyleSheet(f"font-size: {font_size}px;")
        self.button1.clicked.connect(self.plotGraph)

        self.button2 = QPushButton('Filter CSV', self)
        self.button2.setStyleSheet(f"font-size: {font_size}px;")
        self.button2.clicked.connect(self.filterCSV)

        self.button3 = QPushButton('Create WAV', self)
        self.button3.setStyleSheet(f"font-size: {font_size}px;")
        self.button3.clicked.connect(self.createWAV)

        self.button4 = QPushButton('Play WAV', self)
        self.button4.setStyleSheet(f"font-size: {font_size}px;")
        self.button4.clicked.connect(self.playWAV)

        self.button5 = QPushButton('Record Heart Sound', self)
        self.button5.setStyleSheet(f"font-size: {font_size}px;")
        self.button5.clicked.connect(self.openAnotherWindow)
        self.button5.setIcon(QIcon('button1_image.png'))  # Set image for Button 1
        self.button5.setIconSize(QtCore.QSize(100, 200)) 

        button_width = 200
        button_height = 100
        button_spacing = 60

        grid = QGridLayout()
        grid.addWidget(self.button5, 0, 0)
        grid.addWidget(self.button2, 0, 1)
        grid.addWidget(self.button4, 0, 2)
        grid.addWidget(self.button1, 0, 3)
        grid.addWidget(self.button3, 1, 1)

        grid.setSpacing(button_spacing)
        grid.setHorizontalSpacing(button_spacing)

        vbox = QVBoxLayout()
        vbox.addWidget(self.label)
        vbox.addLayout(grid)

        self.setLayout(vbox)
        self.centerWindow()

        self.button1.setFixedSize(button_width, button_height)
        self.button2.setFixedSize(button_width, button_height)
        self.button3.setFixedSize(button_width, button_height)
        self.button4.setFixedSize(button_width, button_height)
        self.button5.setFixedSize(button_width, button_height)

    def centerWindow(self):
        screen_geometry = QDesktopWidget().screenGeometry()
        screen_width = screen_geometry.width()
        screen_height = screen_geometry.height()

        window_width = screen_width // 2
        window_height = screen_height // 2
        x = (screen_width - window_width) // 2
        y = (screen_height - window_height) // 2

        self.setGeometry(x, y, window_width, window_height)

    def plotGraph(self):
        file_paths = filedialog.askopenfilenames(title="Select two CSV files to plot")
        dfs = []
        for file_path in file_paths:
            df = pd.read_csv(file_path)
            dfs.append(df)

        num_files = len(dfs)
        fig, axes = plt.subplots(nrows=num_files, ncols=1, figsize=(8, 5*num_files))

        for i, df in enumerate(dfs):
            ax = axes[i]
            x = df.index
            y = df.iloc[:, 0]
            ax.plot(x, y)
            ax.set_xlabel("Sample")
            ax.set_ylabel("Value")
            ax.set_title(f"CSV Data Plot {i+1}")

            ax.set_xlim(x.min(), x.max())

            def zoom_fun(event):
                axtemp = event.inaxes
                if event.button == 'up':
                    scale_factor = 1 / 1.5
                elif event.button == 'down':
                    scale_factor = 1.5
                else:
                    scale_factor = 1

                x_min, x_max = axtemp.get_xlim()
                y_min, y_max = axtemp.get_ylim()

                x_mid = (x_min + x_max) / 2
                y_mid = (y_min + y_max) / 2
                x_new = (x_min - x_mid) * scale_factor + x_mid
                y_new = (y_min - y_mid) * scale_factor + y_mid

                axtemp.set_xlim(x_new, x_new + (x_max - x_min) * scale_factor)
                axtemp.set_ylim(y_new, y_new + (y_max - y_min) * scale_factor)
                plt.draw()

            fig.canvas.mpl_connect('scroll_event', zoom_fun)

        plt.tight_layout()
        plt.show()

    def filterCSV(self):
        input_file_path = filedialog.askopenfilename(title="Select CSV file to filter")
        output_file_path = filedialog.asksaveasfilename(title="Save filtered CSV file as", defaultextension=".csv")

        with open(input_file_path, 'r') as input_file, open(output_file_path, 'w', newline='') as output_file:
            reader = csv.reader(input_file)
            writer = csv.writer(output_file)

            for row in reader:
                filtered_row = [(float(value)-2087000000) for value in row if 2.08e9 <= float(value) <= 2.11e9]
                writer.writerow(filtered_row)

    def createWAV(self):
        input_file_path = filedialog.askopenfilename(title="Select filtered CSV file")
        output_file_path = filedialog.asksaveasfilename(title="Save WAV file as", defaultextension=".wav")

        df = pd.read_csv(input_file_path)
        audio_data = np.array(df.iloc[:, 0])
        audio_data = audio_data / np.max(np.abs(audio_data))

        with wave.open(output_file_path, "w") as wav_file:
            wav_file.setnchannels(1)
            wav_file.setsampwidth(2)
            wav_file.setframerate(8000)
            wav_file.writeframes((audio_data * 32767).astype(np.int16).tobytes())

    def playWAV(self):
        audio_file = "Heart Sound.wav"
        with wave.open(audio_file, "rb") as wav_file:
            audio = pyaudio.PyAudio()

            def callback(in_data, frame_count, time_info, status):
                data = wav_file.readframes(frame_count)
                return (data, pyaudio.paContinue)

            stream = audio.open(format=audio.get_format_from_width(wav_file.getsampwidth()),
                                channels=wav_file.getnchannels(),
                                rate=wav_file.getframerate(),
                                output=True,
                                stream_callback=callback)

            stream.start_stream()
            while stream.is_active():
                pass

            stream.stop_stream()
            stream.close()

            audio.terminate()

    def recordHeartSound(self):
        # Add your code here to handle the recording of heart sound
        pass

    def openAnotherWindow(self):
        self.another_window = AnotherWindow()
        self.another_window.show()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MyWindow()
    window.show()
    sys.exit(app.exec_())
