
import socket
import struct
import numpy as np
import keyboard

# UDP settings
HOST = '192.168.43.21'           # use the IP address of the computer running this script
PORT = 80

buffer_size = 256

# create a UDP socket and bind it to the specified port
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((HOST, PORT))

# receive and play the audio data
print('Recording ECG and PCG data...')

ECG_NAME=input_value1+"."+"csv"
PCG_NAME=input_value2+"."+"csv"

while True:
    if keyboard.is_pressed(" "):
        break
    # Rest of your code within the while loop
    else:
         # receive a UDP packet
        data, addr = sock.recvfrom((buffer_size+8) * 4)
    
        # convert the byte string to a NumPy array of 32-bit integers
        audio_data = np.array(struct.unpack('<' + 'i' * (buffer_size+8), data))
        #print(audio_data)
        #print("Len:",len(audio_data))
        with open(PCG_NAME, 'a') as f:
            np.savetxt(f, audio_data[0:256], delimiter=',')
        with open(ECG_NAME, 'a') as j:
            np.savetxt(j, audio_data[256:], delimiter=',')

        
